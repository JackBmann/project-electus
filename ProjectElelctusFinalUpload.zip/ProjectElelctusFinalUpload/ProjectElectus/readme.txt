Instructions

Moving
1.The player cam move his hero by using the W, A, S, and D buttons.
2.By pressing A and D the player can move left and right.
3.Pressing W makes the hero jump 
4.Pressing F allows the hero to fly.

Attacks
1.Pressing Left Click uses the basic attack of the player.
2.Pressing Q allows the character to melee attack.
3.Pressing X uses the character's explosion attack.

Combat
1.Enemies, such as robots, will try to attack your hero throughout the game.
2.If you are hit by one of their attacks you will lose health. If all your health is lost you die.
3.If an enemy attacks you, try to dodge the attack by moving away from it.
4.In order to defeat the robot you must use hit the robot with your powers by pressing the above keys.
5.Throughout the game you should try to dodge the enemies� attacks and destroy the enemies with 
	your attacks.