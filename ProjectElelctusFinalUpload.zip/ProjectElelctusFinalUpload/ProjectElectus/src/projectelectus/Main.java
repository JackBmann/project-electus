package projectElectus;

/**
 * The main class, which initiates the game and shows the Title Screen.
 * @author Jack Baumann
 */
public class Main {
    /**
     * The main method, the method creates and initiates the TitleScren class.
     */
    	public static void main(String args[])
	{ 
		TitleScreen title = new TitleScreen();
	}
}
